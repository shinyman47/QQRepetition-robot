#ifndef FAKE_LOGIN_USER_ID
#define FAKE_LOGIN_USER_ID 1
#endif

#ifndef FAKE_LOGIN_NICKNAME
#define FAKE_LOGIN_NICKNAME "cqcppsdk login nickname"
#endif

#ifndef FAKE_OTHER_USER_ID
#define FAKE_OTHER_USER_ID 2
#endif

#ifndef FAKE_OTHER_NICKNAME
#define FAKE_OTHER_NICKNAME "cqcppsdk other nickname"
#endif

#ifndef FAKE_NAME
#define FAKE_NAME "cqcppsdk name"
#endif

#ifndef FAKE_GROUP_NAME
#define FAKE_GROUP_NAME "cqcppsdk group"
#endif

#ifndef FAKE_COOLQ_ROOT_DIR
#ifdef WIN32
#define FAKE_COOLQ_ROOT_DIR ".\\tmp\\酷Q Fake\\"
#else
#define FAKE_COOLQ_ROOT_DIR "./tmp/酷Q Fake/"
#endif
#endif

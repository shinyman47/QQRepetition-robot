#pragma once

#define MEMBER_USER_ID 1
#define ADMIN_USER_ID 2
#define OWNER_USER_ID 3
#define LOGIN_ID 4
